package utils;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ObjectReader 
{
	Properties objpro;
	
	public ObjectReader() throws IOException
	{
		//String path1 = System.getProperty("user.dir");
		//System.out.println(path1);	 
		String path =  System.getProperty("user.dir")+"\\ObjectRepository\\Object.properties";
		FileReader reader=new FileReader(path);  
		
	  objpro=new Properties();  
	 
			objpro.load(reader);
	}
	
	public String get_BaseURL()
	{
	  return objpro.getProperty("BaseUrl");
	
	}
	 
	public String get_StdUserName()
	{
	  return objpro.getProperty("stdusername");	
	}
	
	public String get_Password()
	{
	  return objpro.getProperty("password");	
	}
	
	public String get_lockUserName()
	{
	  return objpro.getProperty("lockuser");	
	}
	
	public String get_problemUserName()
	{
	  return objpro.getProperty("problemuser");	
	}
	
	public String get_performUserName()
	{
	  return objpro.getProperty("performuser");	
	}
	
	 
	 
}
