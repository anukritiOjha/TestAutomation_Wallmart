package utils;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ReusableMethods {
	
	WebDriver driver;
	ObjectReader or;
	By password = By.id("password");
	By login = By.id("login-button");
	By menu = By.xpath("//button[contains(text(),'Open Menu')]");
	By logout = By.xpath("//*[@id='logout_sidebar_link']");
	
	public ReusableMethods(WebDriver driver) throws IOException
	{
		this.driver = driver;	
		or = new ObjectReader();
	}
	
	public void hard_Wait() throws InterruptedException
	{
		Thread.sleep(3000);
	}
	
	public String verify_Title()
	{
		return driver.getTitle();
		  
	}
	public void click_LoginWithPassword()
	{
		driver.findElement(password).sendKeys(or.get_Password());
		driver.findElement(login).click();
	}
	public void click_Logout() throws InterruptedException
	{
		driver.findElement(menu).click();
		System.out.println("Click menu Sucessfully");
		Thread.sleep(1000);
		driver.findElement(logout).click();
		System.out.println("Logged Out Sucessfully");
	}
	public void clear_LoginFields()
	{
		
	}

}
