package baseClassPages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utils.ObjectReader;

public class LoginPage {
	
	WebDriver driver;
	ObjectReader or;
	By username = By.id("user-name");
	By password = By.id("password");
	By login = By.id("login-button");
	
	
	public LoginPage(WebDriver driver) throws IOException
	{
		this.driver = driver;
		or = new ObjectReader();
	}
	
	public void standard_User_login()
	{
		driver.findElement(username).sendKeys(or.get_StdUserName());
		 
	}
	public void locked_User_login()
	{
		driver.findElement(username).sendKeys(or.get_lockUserName());
		 
	}
	public void problem_User_login()
	{
		driver.findElement(username).sendKeys(or.get_problemUserName());		 
	}
	public void performance_User_login()
	{
		driver.findElement(username).sendKeys(or.get_performUserName());		 
	}
	public void set_password()
	{
		driver.findElement(password).sendKeys(or.get_Password());		 
	}
	public void click_Login()
	{
		driver.findElement(login).click(); 
	}
	public void invalid_User()
	{
		driver.findElement(username).sendKeys("invalid_user");
	}
	public void invalid_Password()
	{
		driver.findElement(password).sendKeys("invalid_password");
	}

}
