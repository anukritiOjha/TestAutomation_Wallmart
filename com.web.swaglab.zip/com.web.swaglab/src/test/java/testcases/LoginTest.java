package testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import baseClassPages.LoginPage;
import browserImplementation.Browsers;
import utils.ObjectReader;
import utils.ReusableMethods;

public class LoginTest {
    private WebDriver driver;
    ObjectReader or;
  //  private String baseUrl = "https://www.saucedemo.com/v1/index.html";
    ReusableMethods rm;
    LoginPage lop;
    Browsers br;

    @BeforeTest
    public void setUp() throws IOException, InterruptedException {
        // Set up WebDriver
        //System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
    	or = new ObjectReader();  
    	br = new Browsers();    
    	driver = br.Launch_Chrome();		 
  	   
  	    rm = new ReusableMethods(driver);
    	rm.hard_Wait();
    	System.out.println("Hai Mohan");
       // driver = new ChromeDriver();
        lop = new LoginPage(driver);
        driver.manage().window().maximize();
       
        
    }

    @Test(priority = 1)
    public void testValidLogin() throws InterruptedException {
        // Navigate to the websit        
    	driver.get(or.get_BaseURL());

        // Enter valid username and password by calling loginpage method and reusable method    
    	lop.standard_User_login();
    	rm.click_LoginWithPassword();
         
        rm.hard_Wait();
        // Verify successful login by checking the presence of an element on the next page
        WebElement productsLabel = driver.findElement(By.xpath("//div[@class='product_label']"));
        Assert.assertTrue(productsLabel.isDisplayed(), "Login not successful");
    }
    
    @Test(priority = 2)
    public void testInvalidLogin() throws InterruptedException {
        // Navigate to the website
    	 driver.get(or.get_BaseURL());

        // Enter invalid username and password
        //driver.findElement(By.id("user-name")).sendKeys("invalid_user");
       // driver.findElement(By.id("password")).sendKeys("invalid_password");
       // driver.findElement(By.id("login-button")).click();
    	 lop.invalid_User();
    	 lop.invalid_Password();
    	 lop.click_Login();
    	 rm.hard_Wait();

        // Verify error message displayed for invalid credentials
        WebElement errorLabel = driver.findElement(By.xpath("//h3[@data-test='error']"));
        Assert.assertTrue(errorLabel.isDisplayed(), "Error message not displayed for invalid credentials");
    }


   

    @AfterTest
    public void tearDown() {
        // Close the browser
        if (driver != null) {
            driver.quit();
        }
    }
}
