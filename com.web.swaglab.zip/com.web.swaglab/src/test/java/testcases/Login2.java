package testcases;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import baseClassPages.LoginPage;
import browserImplementation.Browsers;
import utils.ObjectReader;
import utils.ReusableMethods;
import utils.ScreenShot;

public class Login2
{
	WebDriver driver;
	ObjectReader or;
	Browsers bro;
	LoginPage lop;
	ReusableMethods rm;
	ExtentReports extent;
	ExtentSparkReporter spark;
	ScreenShot sh;

 
	@Test
  public void validate_PageURL() throws InterruptedException, IOException 
  {	 
		String ScreenshotFileName = "validate_PageURL";
		 ExtentTest test = extent.createTest("User Verifying the Application URL..");
		 
		 String actualTitle = rm.verify_Title();
		 try
		 {
			 assertEquals(actualTitle, "Swag Labs1");			 
			 test.log(Status.PASS, "Verfied Title..Testcase Passed...");
			 
		 }
		 catch(AssertionError e)
		 {			 
				// Take screenshot and add it to the Extent report Implementation 2
			    String path = sh.captureScreenshot(driver,ScreenshotFileName);
		        test.log(Status.FAIL, "Verified Title..Testcase Failed..."+e.getMessage());
		        test.addScreenCaptureFromPath(path);
		    }		 
		    test.assignAuthor("Mohan").assignDevice("Windows").assignDevice("Chrome");
		
  }
	 
  @BeforeTest
  public void beforeTest() throws IOException 
  {
	  bro = new Browsers();
	  or = new ObjectReader();		
	  extent = new ExtentReports();
	  spark = new ExtentSparkReporter("ExtentReport/Report1.html");
	  extent.attachReporter(spark);
	  driver = bro.Launch_Chrome();		 
	  driver.get(or.get_BaseURL());		  
	  lop = new LoginPage(driver);
	  rm = new ReusableMethods(driver); 
	  sh = new ScreenShot();

  }

  @AfterTest
  public void afterTest() 
  {
	  extent.flush();
	  driver.quit();

  }
  
  

}
