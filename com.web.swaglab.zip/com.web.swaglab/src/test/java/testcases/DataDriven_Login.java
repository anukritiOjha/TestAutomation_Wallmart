package testcases;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import baseClassPages.LoginPage;
import browserImplementation.Browsers;
import utils.ObjectReader;
import utils.ReusableMethods;

public class DataDriven_Login {
	WebDriver driver;
	LoginPage lp;
	ObjectReader or;
	Browsers bro;
	ReusableMethods rm;
	
	@BeforeMethod
	public void setUp() throws IOException
	{
		lp = new LoginPage(driver);
		or = new ObjectReader();
		bro = new Browsers();
		driver = bro.Launch_Chrome();
		driver.get(or.get_BaseURL());	
		rm = new ReusableMethods(driver);		
	}
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}	
	
	
	@Test(dataProvider = "userDataProvider")
    public void testLogin(String username, String password) throws InterruptedException {
        // Your test logic here, for simplicity let's just print the values
		driver.findElement(By.id("user-name")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.id("login-button")).click();
        System.out.println("Username: " + username + ", Password: " + password);
        //rm.click_Logout();
    }

    @DataProvider(name = "userDataProvider")
    public Object[][] provideUserData() throws IOException {
        // Provide the path to your Excel file
        String excelFilePath = "D:\\Clients\\UST_PT\\CompleteAutomationFrameworkCode\\com.web.swaglab\\DataSource\\DataSet.xlsx";

        // Open the Excel file
        FileInputStream inputStream = new FileInputStream(excelFilePath);
        Workbook workbook = WorkbookFactory.create(inputStream);

        // Get the first sheet
        Sheet sheet = workbook.getSheetAt(0);

        // Get the number of rows in the sheet
        int rowCount = sheet.getPhysicalNumberOfRows();

        // Create a 2D array to store data
        Object[][] data = new Object[rowCount - 1][2]; // Subtract 1 for header row

        // Iterate through rows skipping the header row (assuming header is present)
        for (int i = 1; i < rowCount; i++) {
            Row row = sheet.getRow(i);
            // Assuming username is in the first column (index 0) and password in the second column (index 1)
            String username = row.getCell(0).getStringCellValue();
            String password = row.getCell(1).getStringCellValue();
            data[i - 1][0] = username;
            data[i - 1][1] = password;
        }

        // Close the workbook and return the data
        workbook.close();
        inputStream.close();
        return data;
    }

}
