package testcases;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import baseClassPages.LoginPage;
import browserImplementation.Browsers;
import utils.ObjectReader;
import utils.ReusableMethods;

public class Login
{
	WebDriver driver;
	ObjectReader or;
	Browsers bro;
	LoginPage lop;
	ReusableMethods rm;
	ExtentReports extent;
	ExtentSparkReporter spark;

 
	@Test
  public void validate_PageURL() throws InterruptedException, IOException 
  {	 
		 ExtentTest test = extent.createTest("User Verifying the Application URL..");
		 
		 String actualTitle = rm.verify_Title();
		 try
		 {
			 assertEquals(actualTitle, "Swag Labs1");			 
			 test.log(Status.PASS, "Verfied Title..Testcase Passed...");
			 
		 }
		 catch(AssertionError e)
		 {
			// Take screenshot and add it to the Extent report Implementation 1
		        try {
		            TakesScreenshot screenshot = (TakesScreenshot) driver;
		            String screenshotPath = "./Screenshots/" + "validate_PageURL.png";
		            File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
		            FileUtils.copyFile(srcFile, new File(screenshotPath));
		            test.fail("Verification Failed. Screenshot below: ", MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
		        } catch (Exception ex) {
		            ex.printStackTrace();
		        }
		        test.log(Status.FAIL, "Verified Title..Testcase Failed..."+e.getMessage());		
		    }		 
		    test.assignAuthor("Mohan").assignDevice("Windows").assignDevice("Chrome");
		
  }
	 @Test(dependsOnMethods = "validate_PageURL")
	 public void validate_StdLogin() throws InterruptedException
	 {
		 ExtentTest test = extent.createTest("User Verifying the Login..Page");
		 lop.standard_User_login();
		 rm.click_LoginWithPassword();
		 rm.hard_Wait();
		 rm.click_Logout();
		 test.log(Status.PASS, "Verfied StandardUser Login..Testcase Passed...");
		 test.assignAuthor("Mohan").assignDevice("Windows").assignDevice("Chorome");
		
		 
	 }
	 @Test(dependsOnMethods = "validate_StdLogin")
	 public void validate_LockedLogin() throws InterruptedException
	 {
		 rm.hard_Wait();
		 String ExErrText = "Epic sadface: Sorry, this user has been locked out.";
		 ExtentTest test = extent.createTest("User Verifying the Locked User Login..Page");
		 try
		 {
			 lop.locked_User_login();
			 rm.click_LoginWithPassword();
			 rm.hard_Wait();
			 String AcErrText = driver.findElement(By.xpath("//body/div[2]/div[1]/div[1]/div[1]/form[1]/h3[1]")).getText();
			 System.out.println(AcErrText);
			 try
			 {
				 assertEquals(ExErrText,AcErrText);
				 test.log(Status.PASS, "Verfied Locked User Login..Testcase Passed...");
			 }
			 catch(AssertionError e)
			 {
				 test.log(Status.FAIL, "Verfied Locked User Login..Testcase Failed..."); 
			 }	 
			  
			 test.assignAuthor("Mohan").assignDevice("Windows").assignDevice("Chorome");
		 }
		 catch(Exception e)
		 {
			 test.log(Status.FAIL, "Verfied Locked User Login..Testcase Failed...");
			 test.assignAuthor("Mohan").assignDevice("Windows").assignDevice("Chorome");
			 
		 }		
		 
	 }
	 @Test(dependsOnMethods = "validate_LockedLogin")
	 public void validate_problem_Login() throws InterruptedException
	 {
		 rm.hard_Wait();
		 ExtentTest test = extent.createTest("User Verifying the problem User Login..Page");
		 driver.navigate().refresh();
		 lop.problem_User_login();
		 rm.click_LoginWithPassword();
		 rm.hard_Wait();
		 rm.click_Logout();
		 test.log(Status.PASS, "Verfied problem User Login..Testcase Passed...");
		 test.assignAuthor("Mohan").assignDevice("Windows").assignDevice("Chorome");
		 rm.hard_Wait();
		 
	 }
	 @Test(dependsOnMethods = {"validate_problem_Login"})
	 public void validate_Perform_Login() throws InterruptedException
	 {
		 rm.hard_Wait();
		 ExtentTest test = extent.createTest("User Verifying the Perform User Login..Page");
		 lop.performance_User_login();
		 rm.click_LoginWithPassword();
		 rm.hard_Wait();
		 rm.click_Logout();
		 test.log(Status.PASS, "Verfied Perform User Login..Testcase Passed...");
		 test.assignAuthor("Mohan").assignDevice("Windows").assignDevice("Chorome");
		 rm.hard_Wait();
		 
	 }
  @BeforeTest
  public void beforeTest() throws IOException 
  {
	  bro = new Browsers();
	  or = new ObjectReader();		
	  extent = new ExtentReports();
	  spark = new ExtentSparkReporter("ExtentReport/Report.html");
	  extent.attachReporter(spark);
	  driver = bro.Launch_Chrome();		 
	  driver.get(or.get_BaseURL());		  
	  lop = new LoginPage(driver);
	  rm = new ReusableMethods(driver); 

  }

  @AfterTest
  public void afterTest() 
  {
	  extent.flush();
	  driver.quit();

  }

}
