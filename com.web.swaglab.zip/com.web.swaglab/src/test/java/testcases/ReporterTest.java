package testcases;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ReporterTest {
	ExtentReports extent;
	ExtentSparkReporter spark;

	@Test
	public void testcase1() {
		
		ExtentTest test = extent.createTest("User Verifying the Application URL..");
		test.log(Status.PASS, "Testcase 1 passed");
		test.assignAuthor("Mohan").assignDevice("Chrome").assignDevice("Windows");

	}
	
	@Test
	public void testcase2() {
		
		ExtentTest test = extent.createTest("User Verifying the Application Title..");
		
		try
		{
			assertTrue(false);
		}
		catch (AssertionError e) {
			test.log(Status.FAIL, "Testcase 2 Failed"+e.getMessage());
			test.assignAuthor("Mohan").assignDevice("Chrome").assignDevice("Windows");
		 
			System.out.println("Hello Mohan");
		}
	 
		

	}
	
	@Test
	public void testcase3() {
		
		ExtentTest test = extent.createTest("User Verifying the Welcome Message..");
		test.log(Status.PASS, "Testcase 3 passed");
		test.assignAuthor("Mohan").assignDevice("Chrome").assignDevice("Windows");

	}
	
	@Test
	public void testcase4() {
		
		ExtentTest test = extent.createTest("User Verifying the Copyright Message   L..");
		test.log(Status.PASS, "Testcase 4 passed");
		test.assignAuthor("Mohan").assignDevice("Chrome").assignDevice("Windows");

	}

	@BeforeTest
	public void beforeTest() {

		extent = new ExtentReports();
		spark = new ExtentSparkReporter("target/Spark.html");
		extent.attachReporter(spark);

	}

	@AfterTest
	public void afterTest() {
		 extent.flush();
	}

}
