package testcases;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import objectrepositoryreader.ObjectReader;
import pages.LandingPage;
import utils.BrowserImplementation;

public class VerifyLandingPage {
	
	  WebDriver driver;
	  LandingPage lp;
	  BrowserImplementation bi;
	  ObjectReader or;
	  
	  @BeforeMethod
	  public void setUp() throws IOException
	  {
		    bi = new BrowserImplementation();
			or = new ObjectReader();
			driver = bi.Launch_Chrome();
			driver.get(or.get_BaseURL());
	  }
	
	@Test
	public void test_LandingPage1() throws InterruptedException, IOException
	{
		String exText = "Welcome to JPetStore 7";	 
		lp = new LandingPage(driver);
		lp.verify_URL();
		lp.verify_Title();
		String acText = lp.verify_WelcomeText();
		System.out.println(acText);
		SoftAssert softassert = new SoftAssert();
		softassert.assertEquals(exText,acText);
		System.out.println("The Captured Text..."+acText);
		Reporter.log("The Captured Text..."+acText);		
		lp.verify_CopyRightMsg();
		lp.verify_EnterStoreLink();
		Thread.sleep(3000);
		 softassert.assertAll();
		
		
	}
	
	 
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}

}
