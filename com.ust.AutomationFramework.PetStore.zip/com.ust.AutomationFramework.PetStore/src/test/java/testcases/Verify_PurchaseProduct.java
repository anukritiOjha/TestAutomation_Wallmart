package testcases;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import datasource.DataSet;
import objectrepositoryreader.ObjectReader;
import pages.HomePage;
import pages.LandingPage;
import pages.LoginPage;
import pages.LoginPage2;
import utils.BrowserImplementation;
import utils.ReusableMethods;

public class Verify_PurchaseProduct {
	
	  WebDriver driver;
	  LoginPage2 lop;
	  LandingPage lp;
	  BrowserImplementation bi;
	  ObjectReader or;
	  HomePage hp;
	  ReusableMethods rm;
	  
	  
	  @BeforeTest
	  public void setUp() throws IOException
	  {
		    bi = new BrowserImplementation();
			or = new ObjectReader();		
			driver = bi.Launch_Chrome();
			driver.get(or.get_BaseURL());
			rm = new ReusableMethods(driver);
			lop = new LoginPage2(driver);
	  }
  @Test
  public void purchase_Fish() throws IOException, InterruptedException 
  {
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	  	lp = new LandingPage(driver);
		lp.verify_EnterStoreLink();
		hp = new HomePage(driver);
		
		hp.purchase_Fish();
		rm.get_AddTocart();
		rm.get_CheckOut();
		Thread.sleep(2000);
		lop.user_Login();
	
		}
  @AfterTest
  public void tearDowno() throws IOException
  {
	   driver.quit();		
  }
}
