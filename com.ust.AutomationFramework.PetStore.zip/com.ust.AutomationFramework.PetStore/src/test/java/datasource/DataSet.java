package datasource;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class DataSet {  

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "mohan1", "mohan1" },
      new Object[] { "mohan2", "mohan2" },
      new Object[] { "mohan3", "mohan3" },
    };
  }
}
