package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import objectrepositoryreader.ObjectReader;

public class LoginPage2 {
	
	ObjectReader or;
	WebDriver driver;
	By uname = By.name("username");
	By pwd = By.name("password");
	By login = By.name("signon");
	By SignIn = By.linkText("Sign In");
	
	public LoginPage2(WebDriver driver) throws IOException
	{
		this.driver = driver;
		or = new ObjectReader();
	}
	
	
	public void user_Login() throws InterruptedException
	{
		driver.findElement(SignIn).click();
		driver.findElement(uname).sendKeys(or.get_UserName());
		driver.findElement(pwd).clear();
		driver.findElement(pwd).sendKeys(or.get_Password());
		Thread.sleep(3000);
		driver.findElement(login).click();
	}

}
