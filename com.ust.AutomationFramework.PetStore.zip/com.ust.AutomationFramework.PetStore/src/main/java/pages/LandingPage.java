package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import objectrepositoryreader.ObjectReader;

public class LandingPage
{
	WebDriver driver;
	ObjectReader or;
	public LandingPage(WebDriver driver) throws IOException
	{
		this.driver = driver;
		or = new ObjectReader();
	}
	
	//By welcome_text = By.xpath("//h2[contains(text(),'Welcome to JPetStore 6')]");
	//By enter_store = By.linkText("Enter the Store");
	//By copy_Msg = By.xpath("//sub[contains(text(),'Copyright www.mybatis.org')]");
	
	public void verify_URL()
	{
		System.out.println(driver.getCurrentUrl());
	}
	public void verify_Title()
	{
		System.out.println(driver.getTitle());
	}
	public String verify_WelcomeText()
	{
		WebElement welcomeText = driver.findElement(By.xpath(or.get_WelcomeMsg()));
		
		System.out.println(welcomeText.getText());
 
		return welcomeText.getText();
	}
	public void verify_EnterStoreLink()
	{
		driver.findElement(By.linkText(or.get_EnterStore())).click();
	}
	public void verify_CopyRightMsg()
	{
		WebElement cy_Msg = driver.findElement(By.xpath(or.get_CopyMsg()));
		System.out.println(cy_Msg.getText());
	}

}
