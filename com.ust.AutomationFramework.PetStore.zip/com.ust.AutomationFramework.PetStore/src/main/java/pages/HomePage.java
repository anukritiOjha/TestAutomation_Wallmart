package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import objectrepositoryreader.ObjectReader;

public class HomePage 
{
	ObjectReader or;
	WebDriver driver;
	By fish_gif = By.xpath("//*[@id=\'QuickLinks\']/a[1]/img");
	By fish_pro_id = By.linkText("FI-SW-01");
	 
	
	By fish_text = By.xpath("//tbody/tr[2]/td[2]");
	By fish_Item = By.linkText("EST-1");
 
	
	public HomePage(WebDriver driver) throws IOException
	{
		this.driver = driver;
		or = new ObjectReader();
	}
	
	public void purchase_Fish() throws InterruptedException
	{
		driver.findElement(fish_gif).click();
		driver.findElement(fish_pro_id).click();
		String text = driver.findElement(fish_text).getText();
		System.out.println(text);
		driver.findElement(fish_Item).click();
		Thread.sleep(2000);
		
	}

}
