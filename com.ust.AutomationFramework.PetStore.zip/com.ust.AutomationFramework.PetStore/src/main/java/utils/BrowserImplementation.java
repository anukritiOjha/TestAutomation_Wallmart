package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrowserImplementation 
{
	WebDriver driver;
	public WebDriver Launch_Chrome()
	{
		driver = new ChromeDriver();
		return driver;
	}
	
	public void Launch_Edge()
	{
		driver = new EdgeDriver();
	}
	
	public void Launch_Firefox()
	{
		driver = new FirefoxDriver();
	}

}
