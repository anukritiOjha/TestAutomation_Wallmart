package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ReusableMethods 
{
	WebDriver driver;
	By addToCart = By.linkText("Add to Cart");
	By checkOut = By.linkText("Proceed to Checkout");
	
	public ReusableMethods(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void get_AddTocart()
	{
		driver.findElement(addToCart).click();
	}
	public void get_CheckOut()
	{
		driver.findElement(checkOut).click();
	}
	 

}
