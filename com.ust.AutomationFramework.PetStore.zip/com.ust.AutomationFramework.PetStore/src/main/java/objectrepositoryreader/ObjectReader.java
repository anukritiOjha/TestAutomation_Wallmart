package objectrepositoryreader;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ObjectReader 
{
	Properties objpro;
	
	public ObjectReader() throws IOException
	{
		String path = "D:\\Clients\\UST_PT\\SeleniumPractice\\com.ust.AutomationFramework.PetStore\\ObjectRepository\\object.properties";
		FileReader reader=new FileReader(path);  
		
	  objpro=new Properties();  
	 
			objpro.load(reader);
	}
	
	public String get_BaseURL()
	{
	  return objpro.getProperty("BaseUrl");
	
	}
	public String get_EnterStore()
	{
	  return objpro.getProperty("landingpage.enterstore.link");
	
	}
	public String get_WelcomeMsg()
	{
	  return objpro.getProperty("landingpage.welcomemsg.xpath");
	
	}
	public String get_CopyMsg()
	{
	  return objpro.getProperty("landingpage.copymsg.xpath");
	
	}
	public String get_UserName()
	{
	  return objpro.getProperty("username");
	
	}
	public String get_Password()
	{
	  return objpro.getProperty("password");
	
	}

}
