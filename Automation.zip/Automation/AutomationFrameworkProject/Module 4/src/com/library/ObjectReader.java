package com.library;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;

import com.utils.ExcelConfig;
import com.utils.LocatorParser;

public class ObjectReader
{
	//declaring the global variable
	Properties pro;
	ExcelConfig ex;
	By landingPage, homePage, register, username, password, rpassword, fname, lname, email, phone, ad1, ad2, city, state, zip, country, newaccount, login;
	By welcomenote, leftpanel, dogs, dogsAs1, bulldog, bulldogAs, addtocart, addtocartAs, checkout,checkoutAs,paymentdetails,paymentdetailsAs,confirmpayment,confirmpaymentAs,signout;
	By rv;
	LocatorParser l;
	public ObjectReader(Properties pro) throws IOException 
	{
		//importing file of object repository
		this.pro=pro;
		File src = new File("D:\\Zensar Techonologies\\Testing Tranning\\AutomationTesting By Mohan\\Ayush_93357_JpetStoreProject\\ObjectRepository\\objectRepository.properties");
		//fetching the data from the file
		String path = System.getProperty("user.dir");
		ex = new ExcelConfig(path+"//TestData//TestArtifacts.xlsx");
		FileInputStream fis = new FileInputStream(src);
		// loading that data to properties
		pro.load(fis);
		l= new LocatorParser();
	}
	
	
	//Implementing getter setter concept
	public By landingpage()
	{
		landingPage =l.locaterParser(ex.getData(1, 3, 2));
		return landingPage;
	}
	public By homepage()
	{
		homePage =l.locaterParser(ex.getData(1, 5, 2));
		return homePage;
	}
	public By register()
	{
		register =l.locaterParser(ex.getData(1, 4, 2));
		return register;
	}
	public By username()
	{
		username =l.locaterParser(ex.getData(1, 6, 2));
		return username;
	}
	public By password()
	{
		password =l.locaterParser(ex.getData(1, 7, 2));
		return password;
	}
	public By rpassword()
	{
		rpassword =l.locaterParser(ex.getData(1, 8, 2));
		return rpassword;
	}
	public By fname()
	{
		fname =l.locaterParser(ex.getData(1, 9, 2));
		return fname;
	}
	public By lname()
	{
		lname = l.locaterParser(ex.getData(1, 10, 2));
		return lname;
	}
	public By email()
	{
		email =l.locaterParser(ex.getData(1, 11, 2));
		return email;
	}
	public By phone()
	{
		phone =l.locaterParser(ex.getData(1, 12, 2));
		return phone;
	}
	public By ad1()
	{
		ad1 =l.locaterParser(ex.getData(1, 13, 2));
		return ad1;
	}
	public By ad2()
	{
		ad2 =l.locaterParser(ex.getData(1, 14, 2));
		return ad2;
	}
	public By city()
	{
		city =l.locaterParser(ex.getData(1, 15, 2));
		return city;
	}
	public By state()
	{
		state =l.locaterParser(ex.getData(1, 16, 2));
		return state;
	}
	public By zip()
	{
		zip =l.locaterParser(ex.getData(1, 17, 2));
		return zip;
	}
	public By country()
	{
		country =l.locaterParser(ex.getData(1, 18, 2));
		return country;
	}
	public By newaccount()
	{
		newaccount =l.locaterParser(ex.getData(1, 19, 2));
		return newaccount;
	}
	public By login()
	{
		login =l.locaterParser(ex.getData(1, 20, 2));
		return login;
	}
	public By welcomenote()
	{
		welcomenote =l.locaterParser(ex.getData(1, 21, 2));
		return welcomenote;
	}
	
	public By signout()
	{
		signout = l.locaterParser(ex.getData(1, 22, 2));
		return signout;
	}
	public String xl()
	{
		String xl = "D://Data_Driven.xlsx";
		System.out.println(xl);
		return xl;
	}
	public String url()
	{
		String url = pro.getProperty("URL");
		return url;
	}
	public By rv()
	{
		return rv = l.locaterParser(ex.getData(2, 2, 1));
	}
	




}
