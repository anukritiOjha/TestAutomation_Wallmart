package com.testcases;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.config.BrowserConfig;
import com.library.CaptureScreenShot;
import com.library.ObjectReader;
import com.pages.HomePage;
import com.pages.LandingPage;
import com.pages.LoginWithPerametersXml;
import com.pages.Register;
import com.pages.SignOut;
import com.utils.ExcelConfig;
import com.utils.TitleVerification;

public class Module4
{
	WebDriver driver; // define driver globally
	Properties pro; // define properties globally
	int browser=0; // define int for the choice of browser 
	BrowserConfig brCfg;
	public static ExcelConfig ex = null;
	@BeforeMethod // before test will execute before every test
	public void starttest() throws IOException
	{
		pro = new Properties(); // invoking properties
		new ObjectReader(pro); // invoking objectReader and passing the properties in that..
		brCfg = new BrowserConfig(pro);



	}
	@DataProvider
	public static Object[][] getData(){ // Data Provider fetch the data from excel and provide it for the test case


		if(ex == null)
		{
			String path = System.getProperty("user.dir");
			ex = new ExcelConfig(path+"//TestData//TestArtifacts.xlsx");
		}
		int rowcount = ex.getRowCount(0);
		System.out.println(rowcount);
		Object[][] data = new Object[rowcount-1][12];
		for(int i =1;i<rowcount;i++) {


			for(int j =0;j<12;j++) 
			{
				data[i-1][j]=data[i-1][j]=ex.getData(0, i, j);

			}
		}

		return data;


	}



	@Test(dataProvider="getData") // test annotation is defined for making understand to TestNG,this is a test case 
	public void  openBrowser_Launch_App(String uname,String pass,String fname,String lname,String email,String phone,String ad1,String ad2,String city,String state,String zip,String country) throws IOException, InterruptedException
	{

		ObjectReader or = new ObjectReader(pro);
		driver = brCfg.setUp(or.url());
		Reporter.log("Url Opened: "+pro.getProperty("URL"),true);
		//Synchronization via implicit wait
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);



		driver.get(or.url()); // opening the link
		Reporter.log("Site Opened Loaded Sucessfully", true);
		TitleVerification t = new TitleVerification(driver);
		t.titleVerify();//verifing the title of the page
		LandingPage lp = new LandingPage(driver,pro); // calling method Enter the Store
		lp.click_EnterStore();




		t.titleVerify();//verifing the title of the page
		HomePage hp = new HomePage(driver,pro); // calling method home page
		hp.click_SignIn();




		t.titleVerify();//verifing the title of the page
		Register r = new Register(driver,pro);
		r.register(uname, pass,fname,lname,email,phone,ad1,ad2,city,state,zip,country);
		HomePage hp1 = new HomePage(driver,pro);
		hp1.click_SignIn();



		t.titleVerify();//verifing the title of the page
		LoginWithPerametersXml l = new LoginWithPerametersXml(driver,pro); // calling login method
		l.acc_Login(uname,pass);




		t.titleVerify();//verifing the title of the page
		SignOut so = new SignOut(driver,pro); // Signing out from the store
		so.signout();



	}







	@AfterMethod
	public void close_Browser(ITestResult result) throws IOException
	{
		//Quitting the browser after the test done

		if(ITestResult.FAILURE==result.getStatus())
		{
			new CaptureScreenShot(driver,result.getName());
		}
		driver.quit();
		Reporter.log("Browser closed Sucessfully", true);
	}



}
