package com.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelConfig
{
	XSSFWorkbook wb;
	XSSFSheet sh;
	FileInputStream fis;
	public ExcelConfig(String path)
	{
		File file =  new File(path);

		try
		{
			fis = new FileInputStream(file);
			wb = new XSSFWorkbook(fis);
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
		
	}

	public String getData(int sheetNumber,int rowCount,int col)
	{
		//String data;
		sh=wb.getSheetAt(sheetNumber);
        DataFormatter df=new DataFormatter();
        Cell c=sh.getRow(rowCount).getCell(col);
        String data=df.formatCellValue(c);
        return data;
		
		
		/*
		 * try { data = sh.getRow(rowCount).getCell(col).getStringCellValue();
		 * 
		 * } catch (IllegalStateException e) { // TODO Auto-generated catch block data =
		 * String.valueOf(sh.getRow(rowCount).getCell(col).getStringCellValue()); }
		 * return data;
		 */
	}
	
		
		
	public int getRowCount(int sheetindex)
	{
		sh = wb.getSheetAt(sheetindex);
		int rowCount = sh.getLastRowNum()+1;
		return rowCount;

	}
}
