package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class Register 
{

	WebDriver driver;
	Properties pro;
	
	public Register(WebDriver driver,Properties pro) {
		this.driver=driver;
		this.pro=pro;
	}
	public void register(String uname,String pass,String fname,String lname,String email,String phone,String ad1,String ad2,String city,String state,String zip,String country) throws IOException
	{
		ObjectReader or = new ObjectReader(pro);
		
		driver.findElement(or.register()).click();
		driver.findElement(or.username()).sendKeys(uname);
		//driver.findElement(By.name("password")).click();
		Assert.assertTrue(driver.findElement(or.rv()).isDisplayed());
		Reporter.log("Registration Page Validate = Pass",true);
		driver.findElement(or.password()).sendKeys(pass);
		driver.findElement(or.rpassword()).sendKeys(pass);
	
		driver.findElement(or.fname()).sendKeys(fname);

		driver.findElement(or.lname()).sendKeys(lname);

		driver.findElement(or.email()).sendKeys(email);
		
	
		driver.findElement(or.phone()).sendKeys(String.valueOf(phone));
		
	
		
		driver.findElement(or.ad1()).sendKeys(ad1);
		
	
		
		driver.findElement(or.ad2()).sendKeys(ad2);
		

		
		driver.findElement(or.city()).sendKeys(city);
		

		
		driver.findElement(or.state()).sendKeys(state);
		

		
		driver.findElement(or.zip()).sendKeys(zip);
		

		
		driver.findElement(or.country()).sendKeys(country);
		
		
		driver.findElement(or.newaccount()).click();
		Reporter.log("Registration process done sucessfully! ");
	}

}
