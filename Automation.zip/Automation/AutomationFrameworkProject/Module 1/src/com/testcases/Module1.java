package com.testcases;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.pages.HomePage;
import com.pages.LandingPage;
import com.pages.LoginWithPerametersXml;
import com.pages.SignOut;
import com.utils.ExcelConfig;
import com.utils.TitleVerification;
import com.pages.AngleFish;
import com.pages.BullDogs;
import com.pages.CheckOut;
import com.pages.ConfirmPayment;
import com.pages.Dogs;
import com.pages.Fish;
import com.pages.LeftPanel;
import com.pages.LeftPanelD;
import com.pages.PaymentDetails;
import com.config.BrowserConfig;
import com.library.CaptureScreenShot;
import com.library.ObjectReader;
import com.pages.AddToCart;
import com.pages.ValidateConfirmation;

public class Module1
{
	WebDriver driver; // define driver globally
	Properties pro; // define properties globally
	int browser=0; // define int for the choice of browser 
	public static ExcelConfig ex = null;
	@BeforeMethod // before test will execute before every test
	public void starttest() throws IOException
	{
		pro = new Properties(); // invoking properties
		new ObjectReader(pro); // invoking objectReader and passing the properties in that..




	}
	@DataProvider
	public static Object[][] getData(){ // Data Provider fetch the data from excel and provide it for the test case


		if(ex == null)
		{
			String path = System.getProperty("user.dir");
			ex = new ExcelConfig(path+"//TestData//TestArtifacts.xlsx");
		}
		int rowcount = ex.getRowCount(2);

		Object[][] data = new Object[rowcount-1][2];
		for(int i =1;i<rowcount;i++) {


			for(int j =0;j<2;j++) 
			{
				data[i-1][j]=data[i-1][j]=ex.getData(2, i, j);

			}
		}

		return data;


	}



	@Test(dataProvider="getData") // test annotation is defined for making understand to TestNG,this is a test case 
	public void  openBrowser_Launch_App(String uname,String pass) throws IOException, InterruptedException
	{

		ObjectReader or = new ObjectReader(pro);
		BrowserConfig brCfg = new BrowserConfig(pro);
		driver = brCfg.setUp(or.url());
		Reporter.log("Url Opened: "+pro.getProperty("URL"),true);
		//Synchronization via implicit wait
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);





		driver.get(or.url()); // opening the link
		Reporter.log("Site Opened Loaded Sucessfully", true);
		TitleVerification t = new TitleVerification(driver);
		t.titleVerify();//verifying the title of the page
		System.out.println("Before Enter the Store");
		LandingPage lp = new LandingPage(driver,pro); // calling method Enter the Store
		lp.click_EnterStore();




		t.titleVerify();//Verifying the title of the page
		HomePage hp = new HomePage(driver,pro); // calling method home page
		hp.click_SignIn();



		t.titleVerify();//verifying the title of the page
		LoginWithPerametersXml l = new LoginWithPerametersXml(driver,pro); // calling login method
		l.acc_Login(uname,pass);



		LeftPanel ltp= new LeftPanel(driver,pro);
		ltp.left_panel_fish();
		t.titleVerify();//verifying the title of the page

		Fish f = new Fish(driver,pro);
		f.select_fish();
		t.titleVerify();//verifying the title of the page

		AngleFish af = new AngleFish(driver,pro);
		af.select_largeanglefish();
		t.titleVerify();//verifying the title of the page

		AddToCart sc = new AddToCart(driver,pro);
		sc.addToCart();
		t.titleVerify();//verifying the title of the page


		CheckOut ct = new CheckOut(driver,pro);
		ct.checkOut();
		t.titleVerify();//verifying the title of the page

		PaymentDetails pd = new PaymentDetails(driver,pro);
		pd.paymentDetails();
		t.titleVerify();//verifying the title of the page

		ConfirmPayment cp = new ConfirmPayment(driver,pro);
		cp.confirmOrder();
		t.titleVerify();//verifying the title of the page

		ValidateConfirmation vo = new ValidateConfirmation(driver,pro);
		vo.validateOrder();
		t.titleVerify();//verifying the title of the page




		t.titleVerify();//verifing the title of the page
		SignOut so = new SignOut(driver,pro); // Signing out from the store
		so.signout();


		//----------------------------------------Dogs---------------------------------

		t.titleVerify();//verifying the title of the page
		l.acc_Login(uname,pass);

		t.titleVerify();//verifing the title of the page
		LeftPanelD lpd= new LeftPanelD(driver,pro); // clicking on dogs on left panel
		lpd.left_panel_dogs();

		t.titleVerify();//verifing the title of the page
		Dogs d = new Dogs(driver,pro); // choosing dog from catalog
		d.select_dogs();

		t.titleVerify();//verifing the title of the page
		BullDogs bg = new BullDogs(driver,pro); // choosing sub category of specific  dog
		bg.select_male();


		sc.addToCart();
		t.titleVerify();//verifying the title of the page



		ct.checkOut();
		t.titleVerify();//verifying the title of the page


		pd.paymentDetails();
		t.titleVerify();//verifying the title of the page

		cp.confirmOrder();
		t.titleVerify();//verifying the title of the page


		vo.validateOrder();
		t.titleVerify();//verifying the title of the page

		t.titleVerify();//verifing the title of the page
		so.signout();



	}







	@AfterMethod
	public void close_Browser(ITestResult result) throws IOException
	{
		//Quitting the browser after the test done

		if(ITestResult.FAILURE==result.getStatus())
		{
			new CaptureScreenShot(driver,result.getName());
		}
		driver.quit();
		Reporter.log("Browser closed Sucessfully", true);
	}



}
