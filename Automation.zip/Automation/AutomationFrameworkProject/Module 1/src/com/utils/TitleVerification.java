package com.utils;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class TitleVerification
{
	WebDriver driver;
	public TitleVerification(WebDriver driver)
	{
		this.driver=driver;
	}
	public void titleVerify()
	{
		Assert.assertEquals("JPetStore Demo", driver.getTitle()); // verifying the titile of the page
	}
}
