package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.library.ObjectReader;

public class LeftPanel
{
	WebDriver driver;
	Properties pro;
	//Actio
	
	public LeftPanel(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
	}
	public void left_panel_fish() throws IOException
	{
		ObjectReader or = new ObjectReader(pro);
		System.out.println("LeftPanel");
		driver.findElement(or.lpf()).click();
		Reporter.log("clicking on left panel....", true);
		
	}

}
