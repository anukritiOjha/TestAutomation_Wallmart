package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class HomePage 
{
	WebDriver driver;
	Properties pro;
	public HomePage(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
	}
	
	public  void click_SignIn() throws IOException 
	{
		ObjectReader  or = new ObjectReader(pro);
		driver.findElement(or.homepage()).click();
		Assert.assertEquals("www.mybatis.org",driver.findElement(By.linkText(pro.getProperty("jpetstore.home.as1.link"))).getText());
		Reporter.log("cliked on signin button..", true);
		
	}

}
