package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class Dogs 
{
	WebDriver driver;
	Properties pro;
	Actions act;

	public Dogs(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
	
		this.act=new Actions(driver);
	}

	public void select_dogs() throws IOException
	{
		ObjectReader  or = new ObjectReader(pro);// calling object reader
		//assert is using for assuring the elements validation
		Assert.assertEquals("Dogs",driver.findElement(or.dogsAs1()).getText());
		//finding element and clicking on it
		act.moveToElement(driver.findElement(or.dogs())).click().perform();
		Reporter.log("clickin on Bull Dog....", true);

	}

}
