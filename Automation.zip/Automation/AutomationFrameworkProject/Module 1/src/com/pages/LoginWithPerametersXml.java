package com.pages;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class LoginWithPerametersXml 
{
	WebDriver driver;
	Properties pro;
	
	public LoginWithPerametersXml(WebDriver driver,Properties pro)
	{
		
		this.driver=driver;
		this.pro=pro;
	}
	
	public void acc_Login(String uname,String pass) throws IOException 
	{
	
		ObjectReader  or = new ObjectReader(pro); // calling object reader
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS); // Synchronization
		driver.findElement(or.homepage()).click();
	 	driver.findElement(or.username()).sendKeys(uname); // passing username
		Reporter.log("Username Passing "+uname,true);
		driver.findElement(or.password()).click();
		driver.findElement(or.password()).clear();
		driver.findElement(or.password()).sendKeys(pass);
		Reporter.log("password Passing "+pass,true); // pasing password
		driver.findElement(or.login()).click();
		String welcomeNote= "Welcome";
		String status = null;
		
		//boolean b;
		  try { 
			  status=driver.findElement(or.welcomenote()).getText();
			  Assert.assertTrue(status.contains(welcomeNote));
			  Reporter.log("Login Successfull Assert = Pass!",true);
		  System.out.println(status); } 
		  catch(NoSuchElementException e) {
		  Reporter.log("Invalid Username: "+uname+" or Passaaword: "+pass+"", true); 
		//  b=false;
		  } 
		  
		 
		
		
		
	}
	
	
}
