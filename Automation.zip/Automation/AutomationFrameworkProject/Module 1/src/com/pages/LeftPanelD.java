package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;

import com.library.ObjectReader;

public class LeftPanelD
{
	WebDriver driver;
	Properties pro;
	Actions act;
	
	public LeftPanelD(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
		this.act=new Actions(driver); // calling action class for perform actions
	}
	public void left_panel_dogs() throws IOException
	{
		ObjectReader  or = new ObjectReader(pro);// calling object reader
			
		act.moveToElement(driver.findElement(or.leftpaneld())).click().perform();
				
				Reporter.log("clicking on left panel....", true);
			
		
	}

}
