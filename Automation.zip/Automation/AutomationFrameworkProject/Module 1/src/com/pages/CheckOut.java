package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class CheckOut 
{
	WebDriver driver;
	Actions act; // define action class for performing the tasks
	Properties pro;
	
	public CheckOut(WebDriver driver,Properties pro)
	{
		//coping local variable to global variable
		this.driver=driver; 
		this.act=new Actions(driver);
		this.pro=pro;
	}
	
	public void checkOut() throws IOException
	{
		ObjectReader  or = new ObjectReader(pro);// calling object reader
		//assert is using for assuring the elements validation
		Assert.assertEquals("Return to Main Menu",driver.findElement(or.checkoutAs()).getText());
				act.moveToElement(driver.findElement(or.checkout())).click().perform();
				Reporter.log("checkingout...", true);
			
		
	}

}
