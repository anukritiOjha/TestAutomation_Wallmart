package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import com.library.ObjectReader;

public class ConfirmPayment 
{
	WebDriver driver;
	Actions act;
	Properties pro;
	
	public ConfirmPayment(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.act=new Actions(driver);
		this.pro=pro;
	}
	
	public void confirmOrder() throws IOException
	{
		ObjectReader  or = new ObjectReader(pro);// calling object reader
		//assert is using for assuring the elements validation
		Assert.assertEquals("Confirm",driver.findElement(or.confirmpayment()).getText());
				driver.findElement(or.confirmpayment()).click();
			
		
	}

}
