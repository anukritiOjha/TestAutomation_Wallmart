package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class PaymentDetails 
{
	WebDriver driver;
	Actions act;
	Properties pro;
	public PaymentDetails(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.act=new Actions(driver);
		this.pro=pro;
	}

	public void paymentDetails() throws IOException
	{
		
			try {
				ObjectReader or= new ObjectReader(pro);
				Assert.assertTrue(driver.findElement(or.paymentdetailsAs()).isDisplayed());
				act.moveToElement(driver.findElement(By.xpath(pro.getProperty("jpetstore.paymentdetail.xpath")))).click().perform();
				Reporter.log("Entering the payment Details", true);
			} catch (NoSuchElementException e) {
				// TODO Auto-generated catch block
				Reporter.log("Skipped Payment Details because of Invalid Username and password", true);
			}
		
		


	}
}
