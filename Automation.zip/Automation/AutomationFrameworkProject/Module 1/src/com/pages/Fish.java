package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class Fish 
{
	WebDriver driver;
	Properties pro;

	public Fish(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
	}

	public void select_fish() throws IOException
	{
		ObjectReader or = new ObjectReader(pro);
		Assert.assertTrue(driver.findElement(or.angleF()).isDisplayed());
		
		driver.findElement(or.angleF()).click();
		Reporter.log("clickin on Angle Fish....", true);


	}

}
