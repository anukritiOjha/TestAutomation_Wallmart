package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class LandingPage 
{
	WebDriver driver;
	Properties pro;
	
	public LandingPage(WebDriver driver,Properties pro) {
		this.driver=driver;
		this.pro=pro;
	}
	public void click_EnterStore() throws IOException
	{
		ObjectReader or =new ObjectReader(pro);
		//System.out.println(or.landingpage());
		driver.findElement(or.landingpage()).click();
		Assert.assertEquals("JPetStore Demo",driver.getTitle());
		Reporter.log("Entering in the store..", true);
		
		
	}
}
