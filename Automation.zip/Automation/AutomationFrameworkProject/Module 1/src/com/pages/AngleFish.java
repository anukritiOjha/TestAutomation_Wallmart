package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class AngleFish 
{
	WebDriver driver;
	Properties pro;

	public AngleFish(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
	}

	public void select_largeanglefish() throws IOException
	{
		ObjectReader or = new ObjectReader(pro);
		Assert.assertEquals("EST-1",driver.findElement(or.largeAf()).getText());
		driver.findElement(or.largeAf()).click();
		Reporter.log("Large Angle Fish adding to cart.....", true);


	}
}