package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class BullDogs
{WebDriver driver;
Properties pro;
Actions act;

public BullDogs(WebDriver driver,Properties pro)
{
	this.driver=driver;
	this.pro=pro;
	
	this.act=new Actions(driver);
}

public void select_male() throws IOException
{

	ObjectReader  or = new ObjectReader(pro);// calling object reader
	//assert is using for assuring the elements validation
	Assert.assertEquals("Bulldog",driver.findElement(or.bulldogAs()).getText());
	//choosing the male bull dog
	act.moveToElement(driver.findElement(or.bulldog())).click().perform();
	Reporter.log("Large Angle Fish adding to cart.....", true);

}


}
