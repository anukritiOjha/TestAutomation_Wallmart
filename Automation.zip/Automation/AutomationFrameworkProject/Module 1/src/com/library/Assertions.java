package com.library;

public class Assertions {

	public Assertions() {
		// TODO Auto-generated constructor stub
	}

}
