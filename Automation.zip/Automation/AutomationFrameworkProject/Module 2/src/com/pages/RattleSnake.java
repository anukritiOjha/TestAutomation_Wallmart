package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class RattleSnake 
{
	WebDriver driver;
	Properties pro;

	public RattleSnake(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
	}

	public void select_venomlessRattlessnake() throws IOException
	{


		ObjectReader or = new ObjectReader(pro);
		Assert.assertTrue(driver.findElement(or.rattleSnake()).isDisplayed());
		driver.findElement(or.rattleSnake()).click();
		Reporter.log("Clicking on RattleSnake.....", true);


	}
}