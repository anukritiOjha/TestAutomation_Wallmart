package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.library.ObjectReader;

public class TopPanelR
{
	WebDriver driver;
	Properties pro;
	
	public TopPanelR(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
	}
	public void top_panel_reptiles() throws IOException
	{
		ObjectReader or = new ObjectReader(pro);
		driver.findElement(or.lpr()).click();
		Reporter.log("clicking on top panel....", true);
		
	}

}
