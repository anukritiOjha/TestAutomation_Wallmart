package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class Persion
{WebDriver driver;
Properties pro;
Actions act;

public Persion(WebDriver driver,Properties pro)
{
	this.driver=driver;
	this.pro=pro;
	
	this.act=new Actions(driver);
}

public void select_male() throws IOException
{

	ObjectReader  or = new ObjectReader(pro);// calling object reader
	//assert is using for assuring the elements validation
	Assert.assertEquals("Persian",driver.findElement(By.tagName("h2")).getText());
	//choosing the male bull dog
	act.moveToElement(driver.findElement(or.persion())).click().perform();
	Reporter.log("Male persion adding to cart.....", true);

}


}
