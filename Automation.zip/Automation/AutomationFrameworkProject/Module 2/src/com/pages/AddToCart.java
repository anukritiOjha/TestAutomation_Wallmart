package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class AddToCart
{
	WebDriver driver;
	Actions act;
	Properties pro;
	
	public AddToCart(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.act=new Actions(driver);
		this.pro=pro;
	}
	public void addToCart() throws IOException
	{
		ObjectReader or = new ObjectReader(pro);
		try {
			Assert.assertEquals("Add to Cart",driver.findElement(or.addtocart()).getText());
			act.moveToElement(driver.findElement(or.addtocart())).click().perform();
			Reporter.log("Adding to cart....", true);
		} catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			Reporter.log("Skipped add to cart because of Invalid Username and Password",true);
		}
		
		
	}
	
}
