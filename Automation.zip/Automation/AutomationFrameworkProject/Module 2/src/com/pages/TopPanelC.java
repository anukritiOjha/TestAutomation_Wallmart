package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;

import com.library.ObjectReader;

public class TopPanelC
{
	WebDriver driver;
	Properties pro;
	Actions act;
	
	public TopPanelC(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
		this.act=new Actions(driver); // calling action class for perform actions
	}
	public void top_panel_cats() throws IOException
	{
		ObjectReader  or = new ObjectReader(pro);// calling object reader
			
		act.moveToElement(driver.findElement(or.leftpanelc())).click().perform();
				
				Reporter.log("clicking on top panel....", true);
			
		
	}

}
