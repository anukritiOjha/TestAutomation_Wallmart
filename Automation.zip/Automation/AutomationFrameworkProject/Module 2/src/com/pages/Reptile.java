package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class Reptile 
{
	WebDriver driver;
	Properties pro;

	public Reptile(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
	}

	public void select_snake() throws IOException
	{

		ObjectReader or = new ObjectReader(pro);
		Assert.assertTrue(driver.findElement(or.reptile()).isDisplayed());
		driver.findElement(or.reptile()).click();
		Reporter.log("clickin on Reptile RP-SN-01....", true);


	}

}
