package com.utils;

import org.openqa.selenium.By;

public class LocatorParser 
{
	public By locaterParser(String locator) 
	{
		
		By loc = By.id(locator);

		if (locator.contains("id"))
		    loc = By.id(locator.substring(locator.indexOf("\"") + 1,
		        locator.length() - 2));

		else if (locator.contains("name")) {
		    loc = By.name(locator.substring(locator.indexOf("\"") + 1,
		    
		    		locator.length() - 2));
		   
		    }

		if (locator.contains("linkText")) {
		    loc = By.linkText(locator.substring(locator.indexOf("\"") + 1,
		        locator.length() - 2));
		    
		}
		else if (locator.contains("xpath")) {
		    loc = By.xpath(locator.substring(locator.indexOf("\"") + 1,
			        locator.length() - 2));
			   
			}
		if (locator.contains("cssSelector")) {
		    loc = By.cssSelector(locator.substring(locator.indexOf("\"") + 1,
		        locator.length() - 2));
		    
		}
		else if (locator.contains("tagName")) {
		    loc = By.tagName(locator.substring(locator.indexOf("\"") + 1,
		        locator.length() - 2));
		     
		}
		if (locator.contains("partialLinkText")) {
		    loc = By.partialLinkText(locator.substring(locator.indexOf("\"") + 1,
		        locator.length() - 2));
		   
		}
		else if (locator.contains("className")) {
		    loc = By.className(locator.substring(locator.indexOf("\"") + 1,
		        locator.length() - 2));
		  
		}
		return loc;
	}
}
