package com.library;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;

import com.utils.ExcelConfig;
import com.utils.LocatorParser;

public class ObjectReader
{
	//declaring the global variable
	Properties pro;
	ExcelConfig ex;
	By landingPage, homePage, register, username, password, rpassword, fname, lname, email, phone, ad1, ad2, city, state, zip, country, newaccount, login;
	By welcomenote, leftpanelr,leftpanelc,reptile,rattleSnake, cats, dogsAs1, persion, bulldogAs, addtocart, addtocartAs, checkout,checkoutAs,paymentdetails,paymentdetailsAs,confirmpayment,confirmpaymentAs,signout;
	LocatorParser l;
	public ObjectReader(Properties pro) throws IOException 
	{
		//importing file of object repository
		this.pro=pro;
		File src = new File("D:\\Zensar Techonologies\\Testing Tranning\\AutomationTesting By Mohan\\Ayush_93357_JpetStoreProject\\ObjectRepository\\objectRepository.properties");
		//fetching the data from the file 
		String path = System.getProperty("user.dir");
		ex = new ExcelConfig(path+"//TestData//TestArtifacts.xlsx");
		FileInputStream fis = new FileInputStream(src);
		// loading that data to properties
		pro.load(fis);
		l= new LocatorParser();
	}
	
	
	//Implementing getter setter concept
	public By landingpage()
	{
		landingPage =l.locaterParser(ex.getData(1, 3, 2));
		return landingPage;
	}
	public By homepage()
	{
		homePage =l.locaterParser(ex.getData(1, 5, 2));
		return homePage;
	}
	public By username()
	{
		username =l.locaterParser(ex.getData(1, 6, 2));
		return username;
	}
	public By password()
	{
		password =l.locaterParser(ex.getData(1, 7, 2));
		return password;
	}
	
	public By login()
	{
		login =l.locaterParser(ex.getData(1, 20, 2));
		return login;
	}
	public By welcomenote()
	{
		welcomenote =l.locaterParser(ex.getData(1, 21, 2));
		return welcomenote;
	}
	
	public By signout()
	{
		signout = l.locaterParser(ex.getData(1, 22, 2));
		return signout;
	}
	public String xl()
	{
		String xl = "D://Data_Driven.xlsx";
		return xl;
	}
	public String url()
	{
		String url = pro.getProperty("URL");
		return url;
	}
	public By lpr()
	{
		leftpanelr = l.locaterParser(ex.getData(1, 38, 2));
		
		return leftpanelr;
	}
	public By reptile()
	{
		reptile = l.locaterParser(ex.getData(1, 39, 2));
		return reptile;
	}
	public By rattleSnake()
	{
		rattleSnake = l.locaterParser(ex.getData(1, 40, 2));
		return rattleSnake;
	}
	public By leftpanelc()
	{
		leftpanelc =l.locaterParser(ex.getData(1, 42, 2));
		return leftpanelc;
	}
	public By cats()
	{
		cats = l.locaterParser(ex.getData(1, 43, 2));
		return cats;
	}
	public By dogsAs1()
	{
		dogsAs1 = By.cssSelector(pro.getProperty("jpetstoreas1"));
		return dogsAs1;
	}
	public By persion()
	{
		persion = l.locaterParser(ex.getData(1, 44, 2));
		return persion;
	}
	public By bulldogAs()
	{
		bulldogAs = By.xpath(pro.getProperty("jpetstore.bulldog.as1.xpath"));
		return bulldogAs;
	}
	public By addtocart()
	{
		addtocart = l.locaterParser(ex.getData(1, 28, 2));
		return addtocart;
	}
	public By addtocartAs()
	{
		addtocartAs = By.linkText(pro.getProperty("jpetstore.addtocart.as1.link"));
		return addtocartAs;
	}
	public By checkout()
	{
		checkout = l.locaterParser(ex.getData(1, 29, 2));
		return checkout;
	}
	public By checkoutAs()
	{
		checkoutAs = By.linkText(pro.getProperty("jpetstore.as11"));
		return checkoutAs;
	}
	public By paymentdetails()
	{
		paymentdetails = l.locaterParser(ex.getData(1, 30, 2));
		return paymentdetails;
	}
	public By paymentdetailsAs()
	{
		paymentdetailsAs = By.xpath(pro.getProperty("jpetstore.paymentdetail.as1.xpath"));
		return paymentdetailsAs;
	}
	public By confirmpayment()
	{
		confirmpayment = l.locaterParser(ex.getData(1, 31, 2));
		return confirmpayment;
	}
	public By confirmpaymentAs()
	{
		confirmpaymentAs = l.locaterParser(ex.getData(1, 32, 2));
		return confirmpaymentAs;
	}



}
