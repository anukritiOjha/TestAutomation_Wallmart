package com.config;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Reporter;

public class BrowserConfig {
	
	private WebDriver driver;

	//constructor to set the paths to the driver
	String path = System.getProperty("user.dir");
	public BrowserConfig(Properties pro) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		int browser=0;
		do {
			System.out.println("Please choose the Browser\nPress 1 For Chrome\nPress 2 For MS Edge.\nPress 4 for Exit"); 
			browser = sc.nextInt()
			 ;
		switch(browser) {
			
			
			case 1:
				System.setProperty("webdriver.chrome.driver",path+pro.getProperty("ChromeDriver")); // setting path for browser driver
				driver = new ChromeDriver(); // invoking chrome driver
				Reporter.log("Browser Started",true);
				browser=4;
				break;			
			
			case 2:
				System.setProperty("webdriver.edge.driver", path+pro.getProperty("MsEdgeDriver"));
				driver = new EdgeDriver();
				Reporter.log("Browser Started",true);
				browser=4;
				break;
			case 4: System.out.println("Qutiing....");
					System.exit(0);
				break;
			
			default:
				System.out.println("Please Enter the valid input..");
		}
		}
		while(browser!=4); // exiting from the loop
	}

	//Setup method which takes URL as parameter and return Web driver object
	public WebDriver setUp(String url) {
		
		driver.get(url); // opening the site
		driver.manage().window().maximize(); // Maximizing the window size

		return driver;
	}

}
