package com.config;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;

import com.library.PropertyReader;

/**
 * @author Nick
 * Base class for setting the common methods for code re-usability
 */
public class BrowserConfig {

	private WebDriver driver;

	//constructor to set the paths
	public BrowserConfig(PropertyReader property){

		//setup for getting the input from user for browser
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		int browser = 0;
		do {
			System.out.println(property.browserText());
			browser = sc.nextInt();
	
			switch(browser) {
			case 1:
				System.setProperty("webdriver.gecko.driver", property.getFirefoxPath());
				driver = new FirefoxDriver();
				Reporter.log("Browser Started",true);
				break;
	
			case 2:
				System.setProperty("webdriver.chrome.driver", property.getChromePath());
				driver = new ChromeDriver();
				Reporter.log("Browser Started",true);
				break;			
	
			case 3:
				System.setProperty("webdriver.edge.driver", property.getEdgePath());
				driver = new EdgeDriver();
				Reporter.log("Browser Started",true);
				break;
	
			case 4:
				System.out.println("!!! Exiting... !!!");
				System.exit(0);
				
			default:
				System.out.println("!!! Wrong Browser selection, Choose Agian !!!");
			}
		}while(browser > 4 || browser < 1);
	}

	//Setup method which takes url as parameter and return Web driver object
	public WebDriver setUp(String url) {

		driver.get(url);
		driver.manage().window().maximize();

		return driver;
	}

}
