package com.library;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.Reporter;

public class PropertyReader {

	private Properties pro;
	private String path="";
	
	public PropertyReader() {
		
		//setting up the object repositories
		String path = System.getProperty("user.dir");
		this.path = path;
		File file = new File(path+"\\ObjectRepo\\objectRepo.properties");
		
		FileInputStream fis;
		try {
			fis = new FileInputStream(file);
			pro = new Properties();
			pro.load(fis);
			Reporter.log("Properties File Loaded",true);
		} catch (IOException e) {
			Reporter.log("Properties File Loading Failed",true);
			e.printStackTrace();
		}		
	}
	
	//Methods for getting the properties from object repositories
	public String getUrl() {
		return pro.getProperty("URL");
	}
	
	public String browserText() {
		return pro.getProperty("BrowserSelection");
	}
	
	public String getChromePath() {
		return path + pro.getProperty("ChromeDriver");
	}
	
	public String getFirefoxPath() {
		return path + pro.getProperty("FirefoxDriver");
	}
	
	public String getEdgePath() {
		return path + pro.getProperty("EdgeDriver");
	}
	
	public String getExcelPath() {
		return path + pro.getProperty("ExcelPath");
	}
	
	public String getScreenShotPath() {
		return path + pro.getProperty("ScreenShotPath");
	}
	
	public String getHomeText() {
		return pro.getProperty("homePageText");
	}

	public String getTitleText() {
		return pro.getProperty("TitleText");
	}
	
	public String getCartPageVal() {
		return pro.getProperty("CartPageVal");
	}
	
	public String getCheckoutPageVal() {
		return pro.getProperty("CheckoutPagVal");
	}
	
	public String getPaymentConfirmation() {
		return pro.getProperty("PaymentConfirmation");
	}

	public String getOrderConfirmation() {
		return pro.getProperty("OrderConfirmation");
	}

	public String productSelectionText() {
		return pro.getProperty("ProductSelection");
	}
	
	public String dogSelectionText() {
		return pro.getProperty("DogSelection");
	}
	
	public String fishSelectionText() {
		return pro.getProperty("FishSelection");
	}
	
	public String birdSelectionText() {
		return pro.getProperty("BirdSelection");
	}
	
	public String raptileSelectionText() {
		return pro.getProperty("RaptileSelection");
	}
	
	public String catSelectionText() {
		return pro.getProperty("CatSelection");
	}
	
	public String defaultText() {
		return pro.getProperty("defaultText");
	}
}
