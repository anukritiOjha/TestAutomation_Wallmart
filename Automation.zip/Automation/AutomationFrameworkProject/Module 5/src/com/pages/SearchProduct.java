package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.utils.ExcelReader;
import com.utils.GetLocator;

public class SearchProduct {
	
	private WebDriver driver;
	private ExcelReader reader;
	
	//constructor
	public SearchProduct(WebDriver driver, ExcelReader reader) {
		this.driver = driver;
		this.reader = reader;
	}
	
	//Searching process
	public void search(int[] product) {
		
		//getting the search bar element
		WebElement searchBar = GetLocator.getLocator(driver, reader.data(0, 17, 1), reader.data(0, 17, 2));
		searchBar.clear();
		//sending keywords based on the selection of pet
		searchBar.sendKeys(reader.data(3, product[0], product[1]));
		
		//finding search button
		WebElement searchButton = GetLocator.getLocator(driver, reader.data(0, 24, 1), reader.data(0, 24, 2));
		searchButton.click();
	}
	
	public void chooseProduct(int[] product) {
		//choosing product from the provided output after the search
		WebElement productId = GetLocator.getLocator(driver, reader.data(3, product[0], 8), reader.data(3, product[0], 7));
		productId.click();
	}
	
	public void choosePet() {
		//choosing the pet to buy
		WebElement petId = GetLocator.getLocator(driver, reader.data(0, 23, 1), reader.data(0, 23, 2));
		petId.click();
	}
}
