package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.utils.GetLocator;

public class OpenPage {
	
	//Method For opening any page on the Application
	public static void openPage(WebDriver driver, String locatorType, String locatorName) {
		WebElement page = GetLocator.getLocator(driver, locatorType, locatorName);
		page.click();
	}
}
