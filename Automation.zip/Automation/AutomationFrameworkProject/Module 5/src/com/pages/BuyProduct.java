package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.utils.GetLocator;

public class BuyProduct {
	private WebDriver driver;
	
	//Constructor
	public BuyProduct(WebDriver driver){
		this.driver = driver;
	}
	
	//Selecting the Product to buy
	public void selectProduct(String locatorType, String locatorName) {
		WebElement select = GetLocator.getLocator(driver, locatorType, locatorName);
		select.click();
	}
	
	//Selecting the specific Pet to buy
	public void selectPet(String locatorType, String locatorName) {
		WebElement snake = GetLocator.getLocator(driver, locatorType, locatorName);
		snake.click();
	}
	
}
