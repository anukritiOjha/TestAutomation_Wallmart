package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import com.utils.ExcelReader;
import com.utils.GetLocator;


/**
 * @author Nick
 * Class for the testing of login process on the jpet store 
 */
public class Login {
	
	private WebDriver driver;
	private ExcelReader reader;
	
	//Constructor
	public Login(WebDriver driver, ExcelReader reader){
		this.driver = driver; //provided from the test case
		this.reader = reader;
	}
	
	//Login Method
	public void acLogin(String uName, String pass) {
		
		//Getting the field Elements
		WebElement user = GetLocator.getLocator(driver, reader.data(0, 3, 1), reader.data(0, 3, 2));
		WebElement password = GetLocator.getLocator(driver, reader.data(0, 4, 1), reader.data(0, 4, 2));
		WebElement signIn = GetLocator.getLocator(driver, reader.data(0, 5, 1), reader.data(0, 5, 2));
		
		user.sendKeys(uName);
		password.clear();
		password.sendKeys(pass);
		signIn.click();		
	}
	
	public void signOut() {
		//Signing Out
		WebElement signOut = GetLocator.getLocator(driver, reader.data(0, 20, 1), reader.data(0, 20, 2));
		signOut.click();
	}
	
	//Validating the Successfull Login
	public String loginValidation(String name) {
		String eMsg = "Welcome "+name+"!";
		WebElement welcomeText = GetLocator.getLocator(driver, reader.data(0, 13, 1), reader.data(0, 13, 2));
		String aMsg = welcomeText.getText();
		Assert.assertEquals(aMsg,eMsg);
		if(aMsg.equals(eMsg)) {
			Reporter.log("Login Successfull: "+aMsg,true);
		}
		else {
			Reporter.log("Login Failed: "+name,true);
		}
		return aMsg;
	}
}
