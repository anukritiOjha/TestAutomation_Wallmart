package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import com.utils.ExcelReader;
import com.utils.GetLocator;

public class Checkout {
	
	private WebDriver driver;
	private ExcelReader reader;

	public Checkout(WebDriver driver, ExcelReader reader){
		this.driver = driver;
		this.reader = reader;
	}

	//Opening the Checkout Page
	public void checkoutPage() {
		WebElement checkoutPage = GetLocator.getLocator(driver, reader.data(0, 9, 1), reader.data(0, 9, 2));
		checkoutPage.click();
	}
	
	//Going forward to the Payment details 
	public void payment() {
		
		WebElement newOrder = GetLocator.getLocator(driver, reader.data(0, 10, 1), reader.data(0, 10, 2));
		newOrder.click();
	}
	
	//click on the order Confirmation
	public void confirm_order() {
		WebElement confirm = GetLocator.getLocator(driver, reader.data(0, 11, 1), reader.data(0, 11, 2));
		confirm.click();
	}
	
	//Validating the order
	public String validateOrder(String eMsg) {
		WebElement validateOrder = GetLocator.getLocator(driver, reader.data(0, 12, 1), reader.data(0, 12, 2));
		String aMsg = validateOrder.getText();
		
		//validating the expected and actual result
		Assert.assertEquals(eMsg, aMsg);
		if(aMsg.equals(eMsg)) {
			Reporter.log("Order Placed Successfully",true);
		}else {
			Reporter.log("order didn't placed",true);
		}
		return aMsg;
	}
}
