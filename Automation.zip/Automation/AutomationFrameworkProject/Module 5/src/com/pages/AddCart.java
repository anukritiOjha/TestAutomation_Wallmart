package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import com.utils.ExcelReader;
import com.utils.GetLocator;

public class AddCart {
	
	
	public static void addToCart(WebDriver driver, ExcelReader reader) {
				
		//Locating the web element to add the product into the cart
		WebElement addCart = GetLocator.getLocator(driver, reader.data(0, 8, 1), reader.data(0, 8, 2));
		addCart.click();
	}
	
	public static void checkQuantity(WebDriver driver, ExcelReader reader) {
		//Checking the Quantity of the Product
		try {
			GetLocator.getLocator(driver, reader.data(0, 19, 1), reader.data(0, 19, 2));
			Reporter.log("Quantity: 2",true);
		}catch(Exception e) {
			e.printStackTrace();
			Reporter.log("Quantity is not 2",true);
		}
	}
}
