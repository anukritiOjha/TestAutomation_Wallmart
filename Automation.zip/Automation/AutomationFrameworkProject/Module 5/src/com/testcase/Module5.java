package com.testcase;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.config.BrowserConfig;
import com.library.PropertyReader;
import com.library.ScreenShot;
import com.pages.AddCart;
import com.pages.Checkout;
import com.pages.Login;
import com.pages.OpenPage;
import com.pages.SearchProduct;
import com.utils.ExcelReader;
import com.utils.ProductSelection;
import com.utils.ValidatePage;
import com.utils.ValidateTitle;

public class Module5 {
	private PropertyReader property;
	private int[] product; //for storing the user input to fetch the data from the excel file
	private ExcelReader excelReader;
	private WebDriver driver;
	private SearchProduct search;
	private Checkout checkout;
	private Login login;

	@BeforeTest
	public void getProductDetails() {
		Reporter.log("Module 5: Search the Product according to the user's input and Purchase",true);
		
		property = new PropertyReader();
		product = ProductSelection.productSelection(property);

		excelReader = new ExcelReader(property.getExcelPath());

		//Browser configuration
		BrowserConfig browser = new BrowserConfig(property);
		driver = browser.setUp(property.getUrl());
		Reporter.log("Opening Url...",true);

		//Synchronization with implicit wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test
	public void enterStore() {

		//Validating the url
		String currentUrl = driver.getCurrentUrl();
		Assert.assertEquals(currentUrl, property.getUrl());
		Reporter.log("Url Opened: "+currentUrl,true);


		//open a page with the locators from the excel file
		OpenPage.openPage(driver, excelReader.data(0, 1, 1), excelReader.data(0, 1, 2)); // Enter the store
		ValidateTitle.validate(driver, property.getTitleText()); //Title Validation
		Reporter.log("Entering the store",true);
	}

	@Test(dependsOnMethods = {"enterStore"})
	public void searchAndChoosePet() {
		//searching the Pet on the basis of selection
		search = new SearchProduct(driver, excelReader);
		search.search(product);

		//choosing product from the provided output after the search
		search.chooseProduct(product);
		search.choosePet();
	}

	@Test(dependsOnMethods = {"searchAndChoosePet"})
	public void addToCart() {
		//Processing the cart
		AddCart.addToCart(driver, excelReader);
		ValidateTitle.validate(driver, property.getTitleText()); //Title Validation
		String output = ValidatePage.validatePage(driver, excelReader.data(0, 7, 1), excelReader.data(0, 7, 2), property.getCartPageVal());
		Reporter.log("Cart Page "+output,true);
	}

	@Test(dependsOnMethods = {"addToCart"})
	public void checkoutPage() {
		//opening the CheckOut Page
		checkout = new Checkout(driver, excelReader);
		checkout.checkoutPage();
		ValidateTitle.validate(driver, property.getTitleText()); //Title Validation
	}

	@Test(dependsOnMethods = {"checkoutPage"})
	public void login() {
		//Login Process
		login= new Login(driver, excelReader);

		ValidateTitle.validate(driver, property.getTitleText()); //Title Validation
		login.acLogin(excelReader.data(2, 1, 0),excelReader.data(2, 1, 1)); //login with the user-name and password
		login.loginValidation(excelReader.data(2, 1, 0)); //checking for successful login 
	}

	@Test(dependsOnMethods = {"login"})
	public void searchAndChoosePet1() {
		//searching the same Pet Again and adding it
		search.search(product);

		//choosing product from the provided output after the search
		search.chooseProduct(product);
		search.choosePet();
	}

	@Test(dependsOnMethods = {"searchAndChoosePet1"})
	public void addToCart1() {
		//Processing the cart
		AddCart.addToCart(driver, excelReader);
		ValidateTitle.validate(driver, property.getTitleText()); //Title Validation
		String output = ValidatePage.validatePage(driver, excelReader.data(0, 7, 1), excelReader.data(0, 7, 2), property.getCartPageVal());
		Reporter.log("Cart Page "+output,true);
	}

	@Test(dependsOnMethods = {"addToCart1"})
	public void checkQuantity() {
		//checking the quantity of the product after adding it into the cart
		AddCart.checkQuantity(driver, excelReader);
	}

	@Test(dependsOnMethods = {"checkQuantity"})
	public void checkoutPage1() {
		//opening the CheckOut Page
		checkout = new Checkout(driver, excelReader);
		checkout.checkoutPage();
		ValidateTitle.validate(driver, property.getTitleText()); //Title Validation
	}

	@Test(dependsOnMethods = {"checkoutPage1"})
	public void paymentDetails() {
		checkout.payment();
		ValidateTitle.validate(driver, property.getTitleText()); //Title Validation
		//Payment Page Validation
		String ouput = ValidatePage.validatePage(driver, excelReader.data(0, 22, 1), excelReader.data(0, 22, 2), property.getPaymentConfirmation());
		Reporter.log("Payment Page "+ouput,true);
	}

	@Test(dependsOnMethods = {"paymentDetails"})
	public void confirmOrder() {

		ValidateTitle.validate(driver, property.getTitleText()); //Title Validation
		//Order Confirmation
		checkout.confirm_order();
		checkout.validateOrder(property.getOrderConfirmation());
	}

	@Test(dependsOnMethods = {"confirmOrder"})
	public void signOut() {
		ValidateTitle.validate(driver, property.getTitleText()); //Title Validation
		login.signOut(); // Signing out
		Reporter.log("Signed Out",true);
	}

	@AfterMethod
	public void complete(ITestResult result) throws IOException {
		//using ITestResult.FAILURE is equals to result.getStatus then it enter into if condition
		//if test failed then click a screen shot of the screen
		System.out.println("After method!");
		if(ITestResult.FAILURE==result.getStatus())
		{
			new ScreenShot(driver,result.getName());
		}
	}


	@AfterTest
	public void close() {
		driver.close();
	}
}
