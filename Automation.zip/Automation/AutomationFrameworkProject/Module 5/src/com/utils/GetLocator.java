package com.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GetLocator {
	public static WebElement getLocator(WebDriver driver, String locatorType, String locatorValue) {
	
		if(locatorType.equalsIgnoreCase("xpath")) {
			return driver.findElement(By.xpath(locatorValue));
		}
		else if(locatorType.equalsIgnoreCase("name")) {
			return driver.findElement(By.name(locatorValue));
		}
		else if(locatorType.equalsIgnoreCase("id")) {
			return driver.findElement(By.id(locatorValue));
		}
		else if(locatorType.equalsIgnoreCase("class")) {
			return driver.findElement(By.className(locatorValue));
		}
		else if(locatorType.equalsIgnoreCase("css")) {
			return driver.findElement(By.cssSelector(locatorValue));
		}
		else if(locatorType.equalsIgnoreCase("linkText")) {
			return driver.findElement(By.linkText(locatorValue));
		}
		else if(locatorType.equalsIgnoreCase("tagName")) {
			return driver.findElement(By.tagName(locatorValue));
		}
		else {
			return driver.findElement(By.partialLinkText(locatorValue));
		}
	}

}
