package com.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class ValidatePage {
	public static String validatePage(WebDriver driver, String locatorType, String locatorName, String eMsg) {
		WebElement pageText = GetLocator.getLocator(driver, locatorType, locatorName);
		String aMsg = pageText.getText();
		
		Assert.assertEquals(eMsg, aMsg);
		if(aMsg.equals(eMsg)) return "Processed Successfully";
		return "Process Failed";
	}
}
