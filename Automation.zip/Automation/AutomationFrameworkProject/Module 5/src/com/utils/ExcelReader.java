package com.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	
	private FileInputStream fis;
	private XSSFWorkbook wb;
	private XSSFSheet sh;
	
	public ExcelReader(String path) {
		File file = new File(path);
		try {
			fis = new FileInputStream(file);
			wb = new XSSFWorkbook(fis);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public String data(int sheetIndex, int row, int col) {
		sh = wb.getSheetAt(sheetIndex);
		DataFormatter df=new DataFormatter();
		Cell c=sh.getRow(row).getCell(col);
		String data=df.formatCellValue(c);
		return data;
	}
	
	public int getLastRow(int sheetIndex) {
		sh = wb.getSheetAt(sheetIndex);
		int lastRow = sh.getLastRowNum();
		return lastRow + 1;
	}

}
