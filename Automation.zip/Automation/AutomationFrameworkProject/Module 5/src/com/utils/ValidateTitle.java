package com.utils;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

public class ValidateTitle {
	public static void validate(WebDriver driver,String eMsg) {
		String aMsg = driver.getTitle();
		Assert.assertEquals(eMsg, aMsg);
		if(eMsg.equals(aMsg)) Reporter.log("Title Validation Successful",true);
		else Reporter.log("Title Validation failed",true);
	}
}
