package com.utils;

import java.util.Scanner;

import com.library.PropertyReader;

public class ProductSelection {
	public static int[] productSelection(PropertyReader property) {
		
		//array of int to store the product choice
		int[] choice = new int[2];
		
		//Setup for getting input from user
		System.out.println(property.productSelectionText());
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		do {
			choice[0] = sc.nextInt();
			switch(choice[0]) {
				case 1: //Dog Case
					System.out.println(property.dogSelectionText());
					choice[1] = sc.nextInt();
					break;
				
				case 2: //Cat Case
					System.out.println(property.catSelectionText());
					choice[1] = sc.nextInt();
					break;
				
				case 3: // Fish Case
					System.out.println(property.fishSelectionText());
					choice[1] = sc.nextInt();
					break;
					
				case 4: // Reptiles Case
					System.out.println(property.raptileSelectionText());
					choice[1] = sc.nextInt();
					break;
					
				case 5: // Birds Case
					System.out.println(property.birdSelectionText());
					choice[1] = sc.nextInt();
					break;
				default:
					System.out.println(property.defaultText());
					
			}
			if(choice[0] <= 5 && choice[0] > 0) break;
			
		}while(choice[0]>5);
		return choice;
	}
}
