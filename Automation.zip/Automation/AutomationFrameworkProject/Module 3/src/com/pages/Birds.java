package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class Birds 
{
	WebDriver driver;
	Properties pro;

	public Birds(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
	}

	public void select_bird() throws IOException
	{

		ObjectReader or = new ObjectReader(pro);
		Assert.assertTrue(driver.findElement(By.tagName("h2")).isDisplayed());
		driver.findElement(or.bird()).click();
		Reporter.log("clicked on Bird...", true);


	}

}
