package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

public class ValidateConfirmation 
{
	WebDriver driver;
	Properties pro;
	
	public ValidateConfirmation(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
	}
	
	public void validateOrder() throws IOException
	{
		
		String note= "Thank you, your order has been submitted.";
		boolean status=false;
		try {
			status = driver.findElement(By.xpath(pro.getProperty("jpetstore.validateConfirmation.xpath")+",'Thank you, your order has been submitted.')]")).getText().equals(note);
		} catch (NoSuchElementException e) {
			Reporter.log("Skipped");
		}
		if(status)
			Reporter.log("Order validation test case = Pass..",true);
		else
			Reporter.log("Order in validation test case = Fail..",true);
	}

}
