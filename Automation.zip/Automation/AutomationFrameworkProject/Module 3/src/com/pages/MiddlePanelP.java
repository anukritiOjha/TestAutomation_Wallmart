package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;

import com.library.ObjectReader;

public class MiddlePanelP
{
	WebDriver driver;
	Properties pro;
	Actions act;
	
	public MiddlePanelP(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
		this.act=new Actions(driver); // calling action class for perform actions
	}
	public void mid_panel_birds() throws IOException
	{
		ObjectReader  or = new ObjectReader(pro);// calling object reader
		driver.findElement(or.middlePanelP()).click();
				
				Reporter.log("clicking on mid panel....", true);
			
		
	}

}
