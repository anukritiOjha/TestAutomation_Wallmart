package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class Parrot 
{
	WebDriver driver;
	Properties pro;

	public Parrot(WebDriver driver,Properties pro)
	{
		this.driver=driver;
		this.pro=pro;
	}

	public void select_AmazoneParrot() throws IOException
	{

		
		ObjectReader or = new ObjectReader(pro);
		Assert.assertTrue(driver.findElement(or.parrot()).isDisplayed());
		driver.findElement(or.parrot()).click();
		Reporter.log("Clicking on Parrot.....", true);


	}
}