package com.pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.library.ObjectReader;

public class SignOut 
{
	WebDriver driver;
	Properties pro;
	public SignOut(WebDriver driver,Properties pro)
	{
		this.driver = driver;
		this.pro=pro;
		
	}
	public void signout() throws IOException
	{
		ObjectReader  or = new ObjectReader(pro); // calling object reader
		Assert.assertTrue(driver.findElement(or.signout()).isDisplayed());
			driver.findElement(or.signout()).click();
			Reporter.log("Signout Sucessfully", true);
		
	}

}
